wikbezerra.github.io/Toy Store/toystore.html

wikbezerra.github.io/Toy%20Store/antiques.html

I don't know, but for some reason, basically none of the code that I wrote for the antiques.html file is working. You can check my style.css document,
everything is, it just isn't working. I even went into Inspect Element on the preview page and, specifically, my grid-template-columns: 33% 33% 33% had
a strikethrough, saying Invalid Value Property. Please help, I genuinely don't know what went wrong here.